package com.jli.main;

import android.graphics.Bitmap;

/**
 * 用户信息Bean
 * User: 李杰
 * Date: Mar 21, 2011
 * Time: 11:51:53 AM
 */
public class User {
	
	private String id;
	private String name;
	private String pwd;
	private Double money;
	private Bitmap shot;
	private String cardId;
	private String cardPwd;
	private String chrgBalance;
	
	public User(){
		this.money = 0.0;
		this.name = "";
		this.id = "";
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public Double getMoney() {
		return money;
	}
	public void setMoney(Double money) {
		this.money = money;
	}
	public Bitmap getShot() {
		return shot;
	}
	public void setShot(Bitmap shot) {
		this.shot = shot;
	}
	public String getCardId() {
		return cardId;
	}
	public void setCardId(String cardId) {
		this.cardId = cardId;
	}
	public String getCardPwd() {
		return cardPwd;
	}
	public void setCardPwd(String cardPwd) {
		this.cardPwd = cardPwd;
	}
	public String getChrgBalance() {
		return chrgBalance;
	}
	public void setChrgBalance(String chrgBalance) {
		this.chrgBalance = chrgBalance;
	}
}
