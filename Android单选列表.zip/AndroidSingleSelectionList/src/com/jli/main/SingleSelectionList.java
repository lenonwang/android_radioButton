package com.jli.main;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

/**
 * User: 李杰 
 * Date: 2011-3-29 
 * Time: 下午02:43:46
 * 深圳瑞高信息技术有限公司
 */
public class SingleSelectionList extends Activity implements View.OnClickListener, OnItemClickListener {

	private ImageButton mChancleImgBtn;
	private ImageButton mOkImgBtn;
	private ListView mFriendsListView;
	private List<User> mFriendsList = new ArrayList<User>();
	private User mUser;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.single_selection_list);
		
		mOkImgBtn = (ImageButton)findViewById(R.id.btnYes);
		mOkImgBtn.setOnClickListener(this);
		mChancleImgBtn = (ImageButton)findViewById(R.id.btnNo);
		mChancleImgBtn.setOnClickListener(this);
		
		buildData();
		mFriendsListView = (ListView)findViewById(android.R.id.list);
		mFriendsListView.setAdapter(new EfficientAdapter(this));
		mFriendsListView.setOnItemClickListener(this);
		
	}
	
	@Override
	protected void onRestart() {
		if(mFriendsList.size() != 0)
			buildData();
		mFriendsListView.setAdapter(new EfficientAdapter(this));
		super.onRestart();
	};
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	@Override
	public void onClick(View v) {
		
		Intent it = this.getIntent();
		if(v.getId() == R.id.btnYes && mUser != null){

			Intent intent = this.getIntent();
			Bundle bundle = intent.getExtras();		
			bundle.putString("id", mUser.getId());
			bundle.putString("name", mUser.getName());
			it.putExtras(bundle);
			
			SingleSelectionList.this.setResult(Activity.RESULT_OK, it);
		}else{
			SingleSelectionList.this.setResult(Activity.RESULT_CANCELED, it);
		}
		SingleSelectionList.this.finish();
		
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		
		/**update list UI when item on click*/
		class UpDateListStaus implements Runnable{
			private View mView;
			private EfficientAdapter mAdapt;
			
			public UpDateListStaus(View view, EfficientAdapter adapt){
				this.mAdapt = adapt;
				this.mView  = view;
			}
			
			public void run(){
				
				//update previous on selected item status
				if(mAdapt.getSelectHolder() != null){
				
					mAdapt.getSelectHolder().imgView.setImageBitmap(BitmapFactory.decodeResource(mView.getResources(), R.drawable.rdbtn_2));
				}
				
				//update current on selected item status
				ViewHolder tmp = new ViewHolder();
				tmp.imgView = (ImageView)mView.findViewById(R.id.onSelectSign);
				upDateItemUi(tmp.imgView, true);
				//reset current on selected holder
				mAdapt.setSelectHolder(tmp);
			}
		}
		
		//update current on selected user 
		mUser = mFriendsList.get(position);
		EfficientAdapter adapt = (EfficientAdapter)parent.getAdapter();
		//update current on selected item's position
		adapt.setCurSelectPosition(position);
		new Handler().post(new UpDateListStaus(view,adapt));
	}
	
	
	/**if list no data so ui show "you no friends"*/
	protected void showUiForNoData(){
		if(mFriendsList.size() == 0)
			((TextView)findViewById(android.R.id.empty)).setText(getString(R.string.noFriends));
		else
			((TextView)findViewById(android.R.id.empty)).setText("");
	}
	
	/**update item's status*/
	private void upDateItemUi(ImageView imgView, boolean b){
		if(b){
			imgView.setImageBitmap(BitmapFactory.decodeResource(imgView.getResources(), R.drawable.rdbtn_1));
		}else{
			imgView.setImageBitmap(BitmapFactory.decodeResource(imgView.getResources(), R.drawable.rdbtn_2));
		}
	}
	
	private class EfficientAdapter extends BaseAdapter {

		private LayoutInflater mInflater;
		private ViewHolder mHolder;
		/**on selected item*/
		private ViewHolder mSelectHolder;
		/**on selected item posion*/
		private int mCurSelectPosition = -1;

		public EfficientAdapter(Context context) {

			mInflater = LayoutInflater.from(context);
		}
		
		public void setCurSelectPosition(int mCurSelectPosition) {
			this.mCurSelectPosition = mCurSelectPosition;
		}

		public ViewHolder getSelectHolder() {
			return mSelectHolder;
		}

		public void setSelectHolder(ViewHolder selectHolder) {
			this.mSelectHolder = selectHolder;
		}

		@Override
		public int getCount() {
			return mFriendsList.size();
		}

		@Override
		public Object getItem(int position) {
			return position;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}
		
		@Override
		public void notifyDataSetChanged() {
			
		};
		
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			if (convertView == null) {
				convertView = mInflater.inflate(R.layout.list_item, null);

				mHolder = new ViewHolder();
				
				mHolder.id = (TextView) convertView.findViewById(R.id.userId);
				mHolder.icon = (ImageView) convertView.findViewById(R.id.userShot);
				mHolder.name = (TextView) convertView.findViewById(R.id.name);
				mHolder.imgView = (ImageView) convertView.findViewById(R.id.onSelectSign);

				convertView.setTag(mHolder);
			} else {
				mHolder = (ViewHolder) convertView.getTag();
			}
			//update ui by current item on select or no
			if(position == mCurSelectPosition){
				upDateItemUi(mHolder.imgView,true);
			}else{
				upDateItemUi(mHolder.imgView,false);
			}
			
			User u = mFriendsList.get(position);
			mHolder.id.setText(u.getId());
			mHolder.name.setText(u.getName());
			mHolder.icon.setImageBitmap(u.getShot());

			return convertView;
		}
	}
	private class ViewHolder {
		/** User id*/
		TextView id;
		/**User shot*/
		ImageView icon;
		/**User name*/
		TextView name;
		/**sgin current user on selected or no*/
		ImageView imgView;
	}
	
	private void buildData(){
		for(int i=0;i<50;i++){
			User u = new User();
			u.setId("id"+i);
			u.setName("name"+i);
			u.setShot(BitmapFactory.decodeResource(this.getResources(), R.drawable.user_shot));
			mFriendsList.add(u);
		}
	}
}