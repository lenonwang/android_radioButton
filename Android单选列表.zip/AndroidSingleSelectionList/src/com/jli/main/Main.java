package com.jli.main;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Main extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.main);
		Button btn = (Button)findViewById(R.id.test);
		btn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				User u = new User();
				u.setId("111");
				u.setName("3213");
				u.setPwd("fdsaf");
				u.setMoney(500.0);
				Intent it = new Intent(Main.this,SingleSelectionList.class);
				Bundle bundle = new Bundle();
				bundle.putString("id", u.getId());
				bundle.putString("name", u.getName());
				bundle.putDouble("money", u.getMoney());
				it.putExtras(bundle);
				it.putExtras(bundle);
				startActivityForResult(it,0);
			}});

	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		
		if(Activity.RESULT_OK == resultCode){
			
			User user = upDateUIForUserInfo(data.getExtras());
			
			 Toast.makeText(this, "你选择的是:\n"+"id:"+user.getId()+"\n"+"name:"+user.getName(), Toast.LENGTH_LONG).show();
		}else{
			 Toast.makeText(this, "你取消了选择\n", Toast.LENGTH_LONG).show();
		}
	}
	
	private User upDateUIForUserInfo(Bundle bundle){
		User user = new User();
		user.setId(bundle.getString("id"));
		user.setName(bundle.getString("name"));
		return user;
	}
}

